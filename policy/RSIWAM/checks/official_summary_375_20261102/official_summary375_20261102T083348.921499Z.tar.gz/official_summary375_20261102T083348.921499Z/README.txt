RSIWAM accepted 375-episode partial report, not an official leaderboard result

This snapshot executes the exact official bash scripts/robodojo.sh summarize
in a new, isolated report directory. _summary.md, stdout and stderr are untouched.
The eight original _result.json files are copied byte for byte. Full planned
native directory structure is preserved, including missing random halves.

The frozen scope is 7 inherited completed blocks (325 episodes) plus the already
included external general_pickup block (50), totaling 375. The extra 50 must not
be added a second time. In-progress and unaccepted partial results are excluded.
The official table contains 7 complete task/seed cells = 350 episodes out of
126 required cells. arrange_largest_number's 25 standard episodes are retained
but do not form a completed Generalization cell without its 25 random episodes.
Only seed 0 is represented. The 6300-episode campaign is incomplete.

Official scores use dimension-balanced available-cell averages, not pooled
successes divided by 375. They are partial local native metrics, not qualified
failed-state recovery success rates. Zero observed seed spread does not assess
missing seeds/tasks. Read summary_explained.json for the explicit scope.

Existing real source MP4s were checked for existence/size and linked only inside
the new snapshot to enable the official three-camera check. No MP4 was copied,
renamed, modified, fabricated or reencoded. Completion-time media hashes (when
present) are reported as prior hashes and were not recomputed in this snapshot.
The small archive excludes all video links/bytes. Its original video-check output
applies on the source server at snapshot time; a local rerun without obtaining
the videos must report missing videos. Public video delivery is tracked separately.

Raw owner status, run-control configuration and source acceptance audit originals
are retained in a separate private provenance archive, not in this public report.
Their hashes/source paths bind the derived scope. No GPU process, live run,
shared configuration or original result was changed. Previous snapshots remain.
