RSIWAM local native evaluation - official summarize snapshot

This package contains the untouched output of bash scripts/robodojo.sh summarize,
unaltered source _result.json files, exact official script copies and checksums,
and a source/video manifest. It is a partial local report, not a complete official
leaderboard result or a qualified failed-state Recovery SR.

Open eval_result/RoboDojo/_summary.md first. Read summarize.stdout.txt for the
official three-camera video check. summary_explained.json explains completed
cells and the official weighting. Missing/incomplete cells remain blank.

Official coverage is 42 tasks x 3 evaluation seeds = 126 cells. Generalization
cells require 25 standard plus 25 random episodes; other cells require 50.
The official overall score is dimension-balanced and must not be replaced by
the pooled success ratio of selectively completed blocks. Available seed spread
does not estimate uncertainty from missing seeds or missing tasks.

Remote report generation used real per-video symlinks to unchanged source media.
The small downloadable archive intentionally excludes all video bytes and links;
video_manifest.json records their exact source paths and snapshot sizes. The
video availability check is valid at the snapshot time on the source server.
The raw JSONs and official summary are independently portable. A local rerun
without obtaining the source videos will correctly report missing videos.
No fake or empty video files are supplied. Native jobs were not interrupted.

The snapshot was read sequentially without pausing running jobs; capture times
are recorded per source. Queue acceptance is separate from the official script's
complete-cell count. Do not turn pending/infrastructure errors into failures.
